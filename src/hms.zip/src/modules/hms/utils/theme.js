export const THEME_PRESETS = [
  { id: 'ayuraauraa', name: 'AYURAAURAA Green', color: '#0f6240', description: 'Signature deep herbal green, calm & trustworthy' },
  { id: 'emerald', name: 'Herbal Emerald', color: '#059669', description: 'Traditional Ayurveda, leaf & vitality' },
  {
    id: 'forest',
    name: 'Deep Forest Green',
    color: '#15803d',
    description: 'Rich herbal sanctuary & classical medicine',
  },
  { id: 'teal', name: 'Ayur Dhanwanthari Teal', color: '#0d9488', description: 'Healing waters, purification & calm' },
  {
    id: 'amber',
    name: 'Sandalwood & Turmeric Gold',
    color: '#d97706',
    description: 'Chandan, Haridra & warm vital ojas',
  },
  {
    id: 'terracotta',
    name: 'Saffron & Terracotta',
    color: '#c2410c',
    description: 'Warm classical Indian clay & fire agni',
  },
  {
    id: 'maroon',
    name: 'Kashaya Decoction Maroon',
    color: '#9f1239',
    description: 'Classical herbal decoction & heart vigor',
  },
  { id: 'blue', name: 'Royal Vedic Indigo', color: '#2563eb', description: 'Modern clinical precision & calm clarity' },
  {
    id: 'purple',
    name: 'Brahmi Lotus Purple',
    color: '#7c3aed',
    description: 'Meditation, mental harmony & spirituality',
  },
];
// Helper to convert hex to RGB
export function hexToRgb(hex) {
  let cleanHex = hex.replace('#', '');
  if (cleanHex.length === 3) {
    cleanHex = cleanHex
      .split('')
      .map((c) => c + c)
      .join('');
  }
  const num = parseInt(cleanHex, 16);
  if (isNaN(num)) {
    return { r: 15, g: 98, b: 64 }; // Default AYURAAURAA green
  }
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255,
  };
}
// Convert RGB to Hex
export function rgbToHex(r, g, b) {
  return (
    '#' +
    [r, g, b]
      .map((x) => {
        const hex = x.toString(16);
        return hex.length === 1 ? '0' + hex : hex;
      })
      .join('')
  );
}
// Extract dominant vibrant color from an image URL or base64 data URL
export function extractDominantColorFromImage(imageSource, onColorExtracted) {
  if (typeof window === 'undefined') return;
  const img = new Image();
  img.crossOrigin = 'Anonymous';
  img.onload = () => {
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      const size = 64;
      canvas.width = size;
      canvas.height = size;
      ctx.drawImage(img, 0, 0, size, size);
      const imageData = ctx.getImageData(0, 0, size, size);
      const data = imageData.data;
      let rSum = 0;
      let gSum = 0;
      let bSum = 0;
      let count = 0;
      // Filter out pure white, pure black, and very low-saturation greys
      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        const a = data[i + 3];
        if (a < 128) continue; // Skip transparent
        const brightness = (r + g + b) / 3;
        if (brightness > 240 || brightness < 20) continue; // Skip near white & black
        const max = Math.max(r, g, b);
        const min = Math.min(r, g, b);
        const saturation = max === 0 ? 0 : (max - min) / max;
        if (saturation > 0.15) {
          // Weight more saturated pixels
          const weight = Math.round(saturation * 10);
          rSum += r * weight;
          gSum += g * weight;
          bSum += b * weight;
          count += weight;
        }
      }
      if (count > 0) {
        const avgR = Math.round(rSum / count);
        const avgG = Math.round(gSum / count);
        const avgB = Math.round(bSum / count);
        const extractedHex = rgbToHex(avgR, avgG, avgB);
        onColorExtracted(extractedHex);
      } else {
        // Fallback default
        onColorExtracted('#0f6240');
      }
    } catch (e) {
      console.warn('Canvas color extraction error, fallback to emerald:', e);
      onColorExtracted('#0f6240');
    }
  };
  img.onerror = () => {
    onColorExtracted('#0f6240');
  };
  img.src = imageSource;
}
// Injects dynamic CSS variables into document.documentElement so all components automatically reflect the clinic's logo color
export function applyDynamicTheme(hexColor) {
  if (typeof document === 'undefined') return;
  const color = hexColor || '#0f6240';
  const rgb = hexToRgb(color);
  const root = document.documentElement;
  root.style.setProperty('--brand-color', color);
  root.style.setProperty('--brand-rgb', `${rgb.r}, ${rgb.g}, ${rgb.b}`);
  root.style.setProperty('--brand-hover', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.88)`);
  root.style.setProperty('--brand-surface', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.08)`);
  root.style.setProperty('--brand-surface-subtle', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.04)`);
  root.style.setProperty('--brand-border', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.25)`);
  root.style.setProperty('--brand-ring', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.4)`);
}
